public class Browser {

    public static void main(String[] args) {
	// write your code here
        BrowserFrame browserFrame = new BrowserFrame();
    }
}
